/*******************************************************************************
* Created by: Matthew Brean
* Created on: 2016-11-13
* Created for: ICS4U
* Assignment: 5b
* Main stub
*******************************************************************************/
package a5b;

import java.util.ArrayList;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub]
		Scanner userIn = new Scanner(System.in);
		int classChosen = -1;
		long numChosen;
		
		//Choosing which function to use
		System.out.println("Which function (number) would you like to access?" 
				+ '\n' + "1. Mnemonics" + '\n' + "2. Number Pattern" + '\n' + "3. Asterisk Pattern");
		
		if (userIn.hasNextInt()){
			classChosen = userIn.nextInt();
			if ((classChosen < 1) || (classChosen >3)){
				System.out.println("Must be 1-3.");
				System.exit(1);
			}
		}
		else {
			System.out.println("That is invalid.");
			System.exit(1);
		}
		
		//Choosing what to input into function
		System.out.println("Enter a number.");
		if (userIn.hasNextInt()){
			numChosen = userIn.nextLong();
			if (classChosen == 1){
				MnemonicClass mnemonic = new MnemonicClass();
				//print the list
				System.out.println(mnemonic.mnemonics(numChosen).toString());
			}
			else if (classChosen == 2){
				NumericPatternClass numericPattern = new NumericPatternClass();
				//print the pattern
				System.out.println(numericPattern.pattern((int)numChosen));
			}
			else if (classChosen == 3){
				HourglassClass hourglass = new HourglassClass();
				//make the pattern (printed inside function)
				hourglass.astPattern((int)numChosen, 1);
			}
		}
		else {
			System.out.println("That is invalid.");
			System.exit(1);
		}
	}

}